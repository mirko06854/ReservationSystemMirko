package back;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import static back.Main.objectMapper;

public class LocalDateDeserializer extends JsonDeserializer<LocalDate> {

    @Override
    public LocalDate deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        // Read the JSON string representing the LocalDate value
        String dateString = jsonParser.getText();

        // Try to parse the JSON string into a LocalDate object
        try {
            return LocalDate.parse(dateString);
        } catch (DateTimeParseException e) {
            String errorMessage = String.format("Failed to parse LocalDate from JSON string: %s", dateString);
            throw new JsonMappingException(errorMessage, e);
        }
    }

    // Create the custom serializers module
    static CustomSerializersModule customSerializersModule = new CustomSerializersModule();

    // Register the custom deserializer with the object mapper
    static {
        objectMapper.registerModule(customSerializersModule);
    }
}
