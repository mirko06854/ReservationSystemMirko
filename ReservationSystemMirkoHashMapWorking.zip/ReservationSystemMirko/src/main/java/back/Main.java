package back;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class is the main class.
 * We have an <b>ObjectMapper</b>
 * that is used for serialize and deserialize Json to back.Table Object
 * and vice-versa
 **/
public class Main {

    public static ObjectMapper objectMapper = new ObjectMapper();
    static Map<LocalDate, List<Reservation>> reservationsMap = new HashMap<>();

    public static void main(String[] args) {

        // Create a new back.Table instance
        Table table = new Table(3, 4);

        try {
            // Serialize the Table object to JSON and write it to a file
            objectMapper.writeValue(new File("src/main/resources/tables.json"), reservationsMap);

            // Deserialize the JSON from the file back into a Table object
            Table deserializedTable = objectMapper.readValue(new File("src/main/resources/tables.json"), Table.class);

            // Print the deserialized Table object
            System.out.println("Deserialized back.Table: " + deserializedTable);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void serializeJsonFile() {
        File file = new File("src/main/resources/tables.json");
        try {
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
            objectMapper.writeValue(file, reservationsMap);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Loads reservations from a JSON file and populates the application's data structures.
     * If the file exists, it reads the reservations and creates corresponding displays.
     * Reservations and their displays are added to internal collections.
     */
    public static void loadReservedTables() {
        try {
            File file = new File("src/main/resources/tables.json");
            if (file.exists()) {
                TypeReference<HashMap<LocalDate, List<Reservation>>> typeRef =
                        new TypeReference<HashMap<LocalDate, List<Reservation>>>() {
                        };
                reservationsMap = objectMapper.readValue(file, typeRef);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
}

    /**
     * Retrieves the list of reservations for a specific date.
     *
     * @param date The date for which to retrieve reservations.
     * @return A list of reservations for the specified date, or an empty list if none are found.
     */
    public static List<Reservation> getReservationsForDate (LocalDate date){
        return reservationsMap.getOrDefault(date, Collections.emptyList());
    }
}