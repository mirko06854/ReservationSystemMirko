package back;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.Module;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.deser.Deserializers;

public class CustomSerializersModule extends Module {

    @Override
    public String getModuleName() {
        return "CustomSerializersModule";
    }

    @Override
    public Version version() {
        return new Version(1, 0, 0, "");
    }

    @Override
    public void setupModule(Module.SetupContext context) {
        // Create a list to hold the deserializer
        List<Deserializers> deserializers = new ArrayList<>();

        // Add the LocalDateDeserializer to the list
        deserializers.add(new Deserializers.Base() {
            public JsonDeserializer<?> findBeanDeserializer(
                    com.fasterxml.jackson.databind.DeserializationConfig config,
                    com.fasterxml.jackson.databind.JavaType type,
                    com.fasterxml.jackson.databind.BeanDescription beanDesc
            ) {
                if (type.getRawClass() == LocalDate.class) {
                    return new LocalDateDeserializer();
                }
                return null;
            }
        });

        // Register the deserializers with the SetupContext
        context.addDeserializers(new Deserializers.Base() {
            public JsonDeserializer<?> findBeanDeserializer(
                    com.fasterxml.jackson.databind.DeserializationConfig config,
                    com.fasterxml.jackson.databind.JavaType type,
                    com.fasterxml.jackson.databind.BeanDescription beanDesc
            ) {
                if (type.getRawClass() == LocalDate.class) {
                    return new LocalDateDeserializer();
                }
                return null;
            }
        });
    }
}
